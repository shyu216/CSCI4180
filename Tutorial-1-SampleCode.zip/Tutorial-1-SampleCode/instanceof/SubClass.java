public class SubClass extends SuperClass {
	public SubClass() {
		this.name = "SubClass";
	}
}