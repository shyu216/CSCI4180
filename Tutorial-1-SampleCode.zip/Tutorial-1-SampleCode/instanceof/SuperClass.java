public class SuperClass {
	String name;

	public SuperClass() {
		this.name = "SuperClass";
	}
	
	public String whoami() {
		return this.name;
	}
}