public class SubSubClass extends SubClass {
	public SubSubClass() {
		this.name = "SubSubClass";
	}
}