public class Data<CustomType> {
	public CustomType data;

	public Data( CustomType d ) {
		data = d;
	}

	public CustomType getData() {
		return data;
	}

	public void setData( CustomType d ) {
		data = d;
	}
}
